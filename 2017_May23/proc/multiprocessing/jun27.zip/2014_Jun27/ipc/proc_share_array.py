from multiprocessing import Process, Array
from time import sleep


arr = Array('i', range(10, 20))


def foo(a):
    for i, n in enumerate(a):
        a[i] = n*n


def bar(a):
    sleep(2)
    print "In bar: a =", list(a)
    for i, n in enumerate(a):
        a[i] = n / 2



p1 = Process(target=foo, args=(arr,))
p2 = Process(target=bar, args=(arr,))

p1.start()
p2.start()
p1.join()
p2.join()
print "In main: arr =", list(arr)


