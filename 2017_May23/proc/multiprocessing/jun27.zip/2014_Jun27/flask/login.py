from flask import Flask
from flask import request
from flask import session

app = Flask(__name__)

@app.route("/")
def hello():
    if "username" not in session:
        return open("login.html").read().format(
                        header="User Login",
                        action="/login")
    else:
        return "Welcome " + session["username"]

@app.route("/login", methods=["POST"])
def authenticate():
    uname = request.form["uname"]
    password = request.form["password"]

    if uname == "john" and password == "john123":
        session["username"] = "john"
        return "Welcome john"
        
    else:
        return "Authentication failed"


@app.route("/welcome")
def welcome():
    return "Welcome to Python"



if __name__ == "__main__":
    app.run()
