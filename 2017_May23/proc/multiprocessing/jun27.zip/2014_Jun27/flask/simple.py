from flask import Flask
app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello World!"

@app.route("/login/<username>")
def login(username):
    return "This is login page for " + username


if __name__ == "__main__":
    app.run()
