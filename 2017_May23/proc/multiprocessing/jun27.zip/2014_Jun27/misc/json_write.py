info = {
    "name" : "john", 
    "city" : "bengaluru",
    "info" : {"host" : "localhost", "port" : 8080},
    "access" : [ "/home", "/about", "/contact"]
}

import json

print json.dumps(info)


