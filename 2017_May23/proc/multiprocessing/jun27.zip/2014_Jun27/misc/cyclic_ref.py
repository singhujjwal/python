class Car:
    def __init__(self, name):
        self.name = name # instance attribute

    def __del__(self):
        print "Car object", self.name, "destroyed"

class Person:
    def __init__(self, name):
        self.name = name

    def __del__(self):
        print "Person object", self.name, "destroyed"

c1 = Car("Honda")
p1 = Person("Sam")
c1.owner = p1
p1.owns = c1

print "Created c1 and p1"
del c1
print "c1 deleted"
#print p1.name, "owns",  p1.owns.name
del p1
print "p1 deleted"
