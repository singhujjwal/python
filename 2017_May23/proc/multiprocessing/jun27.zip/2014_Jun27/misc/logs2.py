import csv
c = csv.reader(open("a.csv"))
c
# OUT: <_csv.reader object at 0x10825ad70>
for rec in c: print rec

# OUT: ['john', '44', 'delhi']
# OUT: ['sam', '56', 'mumbai']
# OUT: ['smith', '32', 'pune']
# OUT: []
for rec in csv.reader(open("a.csv")): 
    name, age, location = rec
    print name, age
    

# OUT: john 44
# OUT: sam 56
# OUT: smith 32
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 2, in <module>
# OUT: ValueError: need more than 0 values to unpack
import re
re.search(r"\d+", "this is a test string with 44 dsfsdfdsf 2323 ssfsdf 1212")
# OUT: <_sre.SRE_Match object at 0x1087b1578>
m = re.search(r"\d+", "this is a test string with 44 dsfsdfdsf 2323 ssfsdf 1212")
m
# OUT: <_sre.SRE_Match object at 0x1087ac510>
m = re.search(r"\d+", "this is a test string with")
m
m = re.search(r"\d+", "this is a test string with 44 dsfsdfdsf 2323 ssfsdf 1212")
m
# OUT: <_sre.SRE_Match object at 0x1087b17e8>
m.start()
# OUT: 27
a = "this is a test 3434 sdfsdf 234234 ddfg 345345"
m = re.search(r'\d+', a)
m.start()
# OUT: 15
m.end()
# OUT: 19
a[15:19]
# OUT: '3434'
m.string
# OUT: 'this is a test 3434 sdfsdf 234234 ddfg 345345'
m.pos
# OUT: 0
m.endpos
# OUT: 45
a
# OUT: 'this is a test 3434 sdfsdf 234234 ddfg 345345'
a[m.start():m.end()]
# OUT: '3434'
a[:m.start()]
# OUT: 'this is a test '
a[m.end():]
# OUT: ' sdfsdf 234234 ddfg 345345'
for m in re.finditer(r"\d+", a): print a[m.start():m.end()]

# OUT: 3434
# OUT: 234234
# OUT: 345345
re.findall(r"\d+", a)
# OUT: ['3434', '234234', '345345']
re.match(r"this", a)
# OUT: <_sre.SRE_Match object at 0x1087b16b0>
re.match(r"test", a)
pattern = re.compile(r"\d+")
pattern
# OUT: <_sre.SRE_Pattern object at 0x1087a8eb8>
pattern.search(a)
# OUT: <_sre.SRE_Match object at 0x1087b1578>
pattern = re.compile(r"^([a-zA-Z_]\w*)\s*=\s*(\d+)$")
pattern.search("a = 100")
# OUT: <_sre.SRE_Match object at 0x108856ad0>
pattern.search("a     =      100")
# OUT: <_sre.SRE_Match object at 0x108856d78>
pattern.search("a     =  =    100")
m = pattern.search("a     =      100")
m.group(1)
# OUT: 'a'
m.group(2)
# OUT: '100'
pattern2 = re.compile(r'''href\s*=\s*['"](.*?)['"]''')
pattern2.search("ldsfjlkdsjsdfds<b><a href='www.google.com'>Google search</a>sdfsdfsdf")
# OUT: <_sre.SRE_Match object at 0x1087b7030>
m = pattern2.search("ldsfjlkdsjsdfds<b><a href='www.google.com'>Google search</a>sdfsdfsdf")
m.group(1)
# OUT: 'www.google.com'
m.group(0)
# OUT: "href='www.google.com'"
a
# OUT: 'this is a test 3434 sdfsdf 234234 ddfg 345345'
re.sub(r"\d", "-", a)
# OUT: 'this is a test ---- sdfsdf ------ ddfg ------'
re.subn(r"\d", "-", a, 4)
# OUT: ('this is a test ---- sdfsdf 234234 ddfg 345345', 4)
re.search(r"\d{4}", a).end()
# OUT: 19
a[re.search(r"\d{4}", a).end():]
# OUT: ' sdfsdf 234234 ddfg 345345'
re.subn(r"\d", "-", a[re.search(r"\d{4}", a).end():], 4)
# OUT: (' sdfsdf ----34 ddfg 345345', 4)
a[:re.search(r"\d{4}", a).end()] + re.subn(r"\d", "-", a[re.search(r"\d{4}", a).end():], 4)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: cannot concatenate 'str' and 'tuple' objects
a[:re.search(r"\d{4}", a).end()] + re.subn(r"\d", "-", a[re.search(r"\d{4}", a).end():], 4)[0]
# OUT: 'this is a test 3434 sdfsdf ----34 ddfg 345345'
