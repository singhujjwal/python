import sys
import os
import os.path

if len(sys.argv) < 2:
    print >>sys.stderr, "usage: %s path" % sys.argv[0]
    exit(1)


for path, dirs, files in os.walk(sys.argv[1]):
    for f in files: 
        if f[0] in 'pP': print os.path.join(path, f)


