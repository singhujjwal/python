import json
import sys

#data = sys.stdin.read()
data = open("a.json").read()

d = json.loads(data)

for k, v in d.items():
    print k, "->", v

