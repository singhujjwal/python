from urllib import urlopen
import re
import sys

if len(sys.argv) < 2:
    print >>sys.stderr, "usage: %s url" % sys.argv[0]
    exit(1)


pattern = re.compile(r'''href\s*=\s*['"](?P<link>.*?)['"]''', re.IGNORECASE | re.DEBUG)

for link in pattern.finditer(urlopen(sys.argv[1]).read()):
    print link.group('link')

