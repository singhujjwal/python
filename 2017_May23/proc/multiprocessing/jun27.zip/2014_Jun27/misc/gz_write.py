import gzip

with gzip.open("a.gz", "w") as f:
    f.write("dskjsdkjlskdjkdsljdlsf\n")
    f.write("dslkjsdkljsdkljsdlsdlfs\n")


