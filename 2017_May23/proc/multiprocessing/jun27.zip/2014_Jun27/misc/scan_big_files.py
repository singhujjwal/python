import sys
import os
import os.path

if len(sys.argv) < 3:
    print >>sys.stderr, "usage: %s path size" % sys.argv[0]
    exit(1)

size = int(sys.argv[2])

for path, dirs, files in os.walk(sys.argv[1]):
    for f in files: 
        file_path = os.path.join(path, f)
        if os.path.getsize(file_path) > size: print file_path

