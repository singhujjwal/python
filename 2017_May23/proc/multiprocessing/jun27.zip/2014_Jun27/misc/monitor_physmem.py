#!/usr/bin/env python
from time import sleep
import sys
from glob import glob

def get_rss_usage(f):
    with open(f) as status:
        for line in status:
            if "VmRSS" in line:
                return int(line.split(":")[1].strip().split(" ")[0])
        else:
            return 0

try:
    while True:
        total = sum([get_rss_usage(f) for f in glob("/proc/[0-9]*/status")])
        print "\r", total, 
        sys.stdout.flush()
        sleep(1)
except KeyboardInterrupt:
   print "\nExited."





