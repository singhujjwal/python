from subprocess import Popen, PIPE

p = Popen(args=["/sbin/ifconfig", "-a"], stdout=PIPE)
#p = Popen(args=["cmd", "/c", "dir"], stdout=PIPE)

for line in p.stdout:
    if line.strip().startswith("inet "):
        print line.strip().split()[1]

