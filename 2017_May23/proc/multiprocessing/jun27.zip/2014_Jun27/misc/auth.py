from getpass import getpass

name = raw_input("Enter username: ")
password = getpass("Enter password: ")

print name, password

