import sys
import os

if len(sys.argv) < 2:
    print >>sys.stderr, "usage: %s path" % sys.argv[0]
    exit(1)

for path, dirs, files in os.walk(sys.argv[1], topdown=False):
    print "=" * 50
    print "Path:", path
    print "-" * 50
    print "Directories:", dirs
    print "-" * 50
    print "Files:", files
    sys.stdin.readline()

