import sys
import os
import os.path

if len(sys.argv) < 2:
    print >>sys.stderr, "usage: %s path" % sys.argv[0]
    exit(1)

count = 0

for path, dirs, files in os.walk(sys.argv[1]):
    for f in files: 
        if f.endswith(".py"): count += 1

print count, "files"

        #if f.endswith(".py"): print os.path.join(path, f)
 
    #count += len([ x for x in files if x.endswith(".py") ])

#print "Found", count, "python programs"

