from subprocess import Popen, PIPE
from time import time

p = Popen(args=["bc", "-l"], stdout=PIPE, stdin=PIPE)

commands = """
scale=3000
4*a(1)
"""

start = time()
p.stdin.write(commands)
p.stdin.close()

p.wait()
end = time()

print "Duration: ", (end - start), "seconds"

#for line in p.stdout: 
#    print line,


