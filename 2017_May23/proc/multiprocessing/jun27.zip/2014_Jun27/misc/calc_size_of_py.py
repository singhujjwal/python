import sys
import os
import os.path

if len(sys.argv) < 2:
    print >>sys.stderr, "usage: %s path" % sys.argv[0]
    exit(1)

size = 0

for path, dirs, files in os.walk(sys.argv[1]):
    size += sum([ os.path.getsize(os.path.join(path, x)) for x in files if x.endswith(".py") ])

print "Total size:", size

