import os
from sys import argv, stderr

if len(argv) != 3:
   print >>stderr, "usage: %s path size." % argv[0]
   exit(1)

path, size = argv[1:]
size = long(size)


for dirpath, dirs, files in os.walk(path):
    for f in files:
        file_path = os.path.join(dirpath, f)
        if os.path.getsize(file_path) > size: print file_path




