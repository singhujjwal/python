from ConfigParser import ConfigParser
help(ConfigParser)
c = ConfigParser()
c.read("config.ini")
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT:   File "/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/ConfigParser.py", line 297, in read
# OUT:     self._read(fp, filename)
# OUT:   File "/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/ConfigParser.py", line 538, in _read
# OUT:     raise e
# OUT: ParsingError: File contains parsing errors: config.ini
# OUT: 	[line  2]: '    host = localhost\n'
# OUT: 	[line  3]: '    port = 8080\n'
# OUT: 	[line  6]: '    host = 192.168.1.10\n'
# OUT: 	[line  7]: '    port = 5543\n'
# OUT: 	[line  8]: '    max_conn = 100\n'
c.read("config.ini")
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT:   File "/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/ConfigParser.py", line 297, in read
# OUT:     self._read(fp, filename)
# OUT:   File "/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/ConfigParser.py", line 538, in _read
# OUT:     raise e
# OUT: ParsingError: File contains parsing errors: config.ini
# OUT: 	[line  2]: '    host = "localhost"\n'
# OUT: 	[line  3]: '    port = "8080"\n'
# OUT: 	[line  6]: '    host = 192.168.1.10\n'
# OUT: 	[line  7]: '    port = 5543\n'
# OUT: 	[line  8]: '    max_conn = 100\n'
c.read("config.ini")
# OUT: ['config.ini']
c.read("config.ini")
# OUT: ['config.ini']
c.get("main", "host")
# OUT: '"localhost"'
c.get("admin", "max_conn")
# OUT: '100'
c.set("support", "host", "10.33.44.55")
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT:   File "/System/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/ConfigParser.py", line 388, in set
# OUT:     raise NoSectionError(section)
# OUT: NoSectionError: No section: 'support'
c.add_section("support")
c.set("support", "host", "10.33.44.55")
c.set("support", "port", 6000
)
c.set("main", "host", "127.0.0.1")
with open("newconfig.ini", "w") as out: c.write(out)

import json
dir(json)
# OUT: ['JSONDecoder', 'JSONEncoder', '__all__', '__author__', '__builtins__', '__doc__', '__file__', '__name__', '__package__', '__path__', '__version__', '_default_decoder', '_default_encoder', 'decoder', 'dump', 'dumps', 'encoder', 'load', 'loads', 'scanner']
