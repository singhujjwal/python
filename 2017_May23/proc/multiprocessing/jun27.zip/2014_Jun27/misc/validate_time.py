import re

# Valid time -> 00:00:00 to 23:59:59

pattern = re.compile(r"""
        (                   # Match hour group
            [01]\d          # match 00 to 19
            |               # or
            2[0-3]          # match 20 to 23
        )                   # finish hour group
        (                   # group for minutes and seconds
            :               # match : followed by
            [0-5]\d         # 00 to 59
        ){2}                # repeat the pattern for seconds
        """, 
        re.VERBOSE)


while True:
    time_value = raw_input("Enter valid time (hh:mm:ss): ")
    match = pattern.search(time_value)
    if match:
        print "Valid time"
    else:
        print "Invalid time"

