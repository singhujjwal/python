import os

for dpath, subdirs, files in os.walk("."):
    print "Path: ", dpath
    print "subdirs: ", subdirs
    print "files: ", files
    print "-" * 40
    raw_input("Press Enter to continue.")

