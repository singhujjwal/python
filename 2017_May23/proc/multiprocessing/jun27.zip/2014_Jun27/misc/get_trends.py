import urllib
import json

#url = "https://api.twitter.com/1/trends/1.json"
url = "https://api.twitter.com/1.1/trends/place.json?id=1"

print json.loads(urllib.urlopen(url).read())
