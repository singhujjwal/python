import os
import os.path

for dpath, subdirs, files in os.walk("."):
    for f in ( os.path.join(dpath, x) for x in files ):
        if os.path.getsize(f) > 100000: print f, os.path.getsize(f)

