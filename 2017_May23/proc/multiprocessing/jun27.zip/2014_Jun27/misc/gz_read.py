import gzip

with gzip.open("a.gz") as f:
    print f.read()

