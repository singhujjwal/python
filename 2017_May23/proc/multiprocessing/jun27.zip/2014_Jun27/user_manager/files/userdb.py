"""
[ Download link - http://www.chandrashekar.info/files/python/userdb.py ]
Write a program to manage a user account database using simple text file.

Each user account should be represented in a a record of single line 
in the format: "username:password:fullname"

Note that there are three fields per user record separated by a colon (:).

A sample file format should be as below:
    john:john123:John Doe
    smith:w3lc0me:Adrian Smith
    tony:t0ny123:Tony Iommi

Implement a class called 'UserDB' with the following functionality:

   >>> user = UserDB(filename="userdb.dat")

   >>> user.add(name="joe", password="joe333", fullname="Samuel Joe")
   
   >>> user.add(name="joe", password="joe333", fullname="Samuel Joe")
   Traceback (most recent call last):
   ...
   ValueError: "user 'joe' already exists"

   >>> user.delete("joe")
   
   >>> user.delete("joe")
   Traceback (most recent call last):
   ...
   ValueError: "user 'joe' does not exist"

   >>> user.modify(name="john", password="j0hnny")
   
   >>> user.authenticate(name="john", password="sdfsdf")
   False
   
   >>> user.authenticate(name="john", password='j0hnny')
   True

"""

class UserDB:
    """
    Implementation of a simple user account database manager

    Example usage:
    --------------

    >>> user = UserDB(filename="users.dat")

    >>> user.add(name="bourne", password="steve123", fullname="Steven Bourne")
    
    >>> user.exists(name="bourne")
    True

    >>> user.add("bourne", "welcome", "Sam Bourne")
    Traceback (most recent call last):
    ...
    ValueError: user 'bourne' already exists

    >>> user.modify(name="bourne", password="welcome" fullname="Sam Bourne")

    >>> user.modify(name="guest", password="guest123")
    Traceback (most recent call last):
    ...
    ValueError: user 'guest' does not exist
    
    >>> user.delete(name="bourne")

    >>> user.exists("bourne")
    False

    >>> user.delete("bourne")
    Traceback (most recent call last):
    ...
    ValueError: user 'bourne' does not exist

    """
    pass




if __name__ == '__main__':
    import doctest
    doctest.testmod()


