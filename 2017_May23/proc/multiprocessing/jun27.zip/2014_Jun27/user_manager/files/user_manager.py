class UserDB:
    def __init__(self, filename="users.dat"):
        self.filename = filename
        self.db = { }

    def parse(self):
        for line in open(self.filename):
            username, password, fullname = line.strip().split(":") 
            rec = {
                "name"       : username,
                "password"   : password,
                "fullname"   : fullname
            }
            self.db[username] = rec

    def store(self):
        with open(self.filename, "w") as out:
            for k, v in self.db.items():
                out.write("%s:%s:%s\n" % (v["name"], v["password"], v["fullname"]))


    def add(self, name, password, fullname):
        self.parse() 
        if name in self.db:
            raise ValueError, "Username " + name + ": already exists.\n" 

        rec = {
            "name"      : name,
            "password"  : password,
            "fullname"  : fullname
        }
        self.db[name] = rec
        self.store()

    def modify(self, name, password, fullname):
        self.parse() 
        if name not in self.db:
            raise ValueError, "Username " + name + ": does not exist.\n" 

        rec = {
            "name"      : name,
            "password"  : password,
            "fullname"  : fullname
        }
        self.db[name] = rec
        self.store()




