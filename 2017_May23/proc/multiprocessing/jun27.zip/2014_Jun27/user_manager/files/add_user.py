from user_manager import UserDB

u = UserDB("users.dat")

name = raw_input("Enter username: ")
password = raw_input("Enter password: ")
fullname = raw_input("Enter fullname: ")

try:
    u.add(name, password, fullname)
except ValueError as e:
    print "Caught a value error ->", e

print "End of program"


