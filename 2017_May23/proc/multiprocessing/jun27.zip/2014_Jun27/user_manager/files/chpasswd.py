from user_manager import UserDB

u = UserDB("users.dat")

name = raw_input("Enter username: ")
password = raw_input("Enter new password: ")
fullname = raw_input("Enter new fullname: ")

u.modify(name, password, fullname)


