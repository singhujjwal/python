def parse_user(fname):
    db = { }
    for line in open(fname):
        username, password, fullname = line.strip().split(":")
        record = {
            "name": username, 
            "password": password,
            "fullname": fullname
        }
        db[username] = record
    return db
        
def store_user(fname, db):
    with open(fname, "w") as dst:
        for record in db.values():
            dst.write("%s:%s:%s\n" % (record["name"], 
                                    record["password"],
                                    record["fullname"]))



userdb = parse_user("users.dat")
username = raw_input("Enter username: ")
if username not in userdb: 
    print "User", username, "does not exist."
    exit(1)

old_passwd = raw_input("Enter old password: ")
if old_passwd != userdb[username]["password"]:
    print "Invalid password!"
    exit(1)

new_passwd = raw_input("Enter new password: ")
userdb[username]["password"] = new_passwd

store_user("users.dat", userdb)


