def parse_user(fname):
    db = { }
    for line in open(fname):
        username, password, fullname = line.strip().split(":")
        record = {
            "name": username, 
            "password": password,
            "fullname": fullname
        }
        db[username] = record
    return db
        
def store_user(fname, db):
    with open(fname, "w") as dst:
        for record in db.values():
            dst.write("%s:%s:%s\n" % (record["name"], 
                                    record["password"],
                                    record["fullname"]))



userdb = parse_user("users.dat")
username = raw_input("Enter username: ")
if username in userdb: 
    print "User", username, "already exists.\n"
    exit(1)

password = raw_input("Enter password: ")
fullname = raw_input("Enter fullname: ")
record = {
    "name": username,
    "password": password,
    "fullname": fullname
}
userdb[username] = record
store_user("users.dat", userdb)


