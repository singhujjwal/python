import sqlite3

conn = sqlite3.connect("accessdb")

select_sql = """
    SELECT * FROM users
"""

cursor = conn.execute(select_sql)

for uid, username, password in cursor:
    print uid, username, password

conn.close()

    

