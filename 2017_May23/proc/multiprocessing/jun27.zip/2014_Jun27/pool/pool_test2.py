from multiprocessing import Pool, Process
from time import time
from sys import setrecursionlimit

setrecursionlimit(100000)

def fact(x):
    if x <= 1: return 1
    return x * fact(x-1)

# Using simple map() function
data = range(2000)
start = time()
result = map(fact, data)
duration = time() - start
print "Duration:", duration, "seconds"

# Using pool.map function
data = range(2000)
start = time()
p = Pool(16)
result = p.map(fact, data)
duration = time() - start
print "Duration:", duration, "seconds"

# Using pool.apply_async
#data = range(2000)
#start = time()
#p = Pool(16)
#result = p.apply_async(fact, data)
#print "Created process pool to generate factorial..."
#print "Waiting for results to arrive"
#p.join()
#duration = time() - start
#print "Duration:", duration, "seconds"

#result = p.apply_async(fact, data)

#print "Result: ", result.get(1)
#duration = time() - start

#print result





