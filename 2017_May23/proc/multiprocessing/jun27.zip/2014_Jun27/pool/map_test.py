from sys import setrecursionlimit
from time import time

setrecursionlimit(100000)

def fact(x):
    if x <= 1: return 1
    return x * fact(x-1)

# Using simple map() function
data = range(2000)
start = time()
result = map(fact, data)
duration = time() - start
print "Duration:", duration, "seconds"

