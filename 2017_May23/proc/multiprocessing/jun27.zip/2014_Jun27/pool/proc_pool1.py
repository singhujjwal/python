from multiprocessing import Pool
from time import sleep
from random import random, randint

def square(x): return x*x

data = [11, 22, 33, 55, 66, 65, 44, 22, 33, 55, 66, 77, 88, 99, 22, 33, 44, 55, 66]
p = Pool(16)

print "Starting parallel map..."
result = p.map(square, data)

print data
print result

