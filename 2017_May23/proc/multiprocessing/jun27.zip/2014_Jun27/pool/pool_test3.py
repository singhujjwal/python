from multiprocessing import Pool, Process
from time import time

def square(x): return x*x

data = [33, 44, 55, 66, 77, 33] 

#result = map(square, data)

p = Pool(16)
result = p.map(square, data)
print result

#s = time()
#result = map(square, data)
#e = time()

#print "Duration: ", e - s, "seconds"



