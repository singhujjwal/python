from multiprocessing import Pool
from time import time

#def square(x): return x*x

def fibo(x):
    a, b = 0, 1
    for i in range(x): 
        yield a
        a, b = b, a + b

def fibo_sum(x):
    return sum(fibo(x))

data = range(4000)

pool = Pool(16)

start = time()
#result = map(fibo_sum, data)
#result = pool.map(fibo_sum, data) 
pool.apply_async(fibo_sum, data)
duration = time() - start

#print "Result: ", result
print "Duration: ", duration, "seconds"


