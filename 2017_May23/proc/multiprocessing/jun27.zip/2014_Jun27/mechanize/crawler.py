from mechanize import Browser

visited = set([])

def crawl(br):
    print "-" * 40
    for link in br.links():
        if link.url.startswith("#"): continue
        print "Crawling", link.url
        if link.url not in visited:
            visited.add(link.url)
            br.follow_link(link)
            crawl(br)


br = Browser()

br.open("http://www.chandrashekar.info/")

crawl(br)

for v in visited:
    print v.url

