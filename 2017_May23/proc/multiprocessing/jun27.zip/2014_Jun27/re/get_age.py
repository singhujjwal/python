import re

pattern = "^\d\d:\d\d:\d\d$"

while True:
    t = raw_input("Enter time: ")
    if re.match(pattern, t): break
    print "Invalid time - ", t 

print "Time validated..."


