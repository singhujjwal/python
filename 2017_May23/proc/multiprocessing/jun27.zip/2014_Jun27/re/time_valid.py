#!/usr/bin/env python
import sys
import re

regex = "^([01]\d|2[0-3])(:[0-5]\d){2}$"
pattern = re.compile(regex)

try:
    while True:
        data = raw_input("Enter time: ")
        match = pattern.search(data)
        if match:
            print "Valid time" 
        else:
            print "Invalid time"
except:
    print "Bye"

