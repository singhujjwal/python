#!/usr/bin/env python
import sys
import re
usage = "usage: %s path" % sys.argv[0]

if len(sys.argv) < 2:
	print usage
	sys.exit(1)
else:
	path = sys.argv[1]
	pattern = re.compile("/(\w+)/*$")
	matches = pattern.search(path)
	if matches:
		print matches.group(1)

