#!/usr/bin/env python
import sys
import re


pattern = """
    (              # match hour component  
      [01]\d |     # match 00 to 19 or
      2[0-3]       # match 20 to 23
    )
    (              # match minutes component
      :[0-5]\d     # match :00 to :59
    ){2}           # repeat for seconds component
"""

try:
    while True:
        data = raw_input("Enter time (hh:mm:ss): ")
        match = re.search(pattern, data, re.VERBOSE)
        if match:
            print "Extracted valid time: ", match.group()
        else:
            print "Could extract valid time"
except:
    print "Bye"

