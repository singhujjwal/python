import urllib

def urldecode(url):
   query = {}
   (host, query_string) =  url.split('?')
   query_list = query_string.split('&')
   for q in query_list:
      if q.find('='):
         key, value = map(urllib.unquote, q.split('='))
         if query.has_key(key):
            query[key].append(value)
         else:
            query[key] = [value]
 
   return host, query
   
print urldecode("http://www.google.co.in/search?q=Python&lang=en_US&country=IN")
