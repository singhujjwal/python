#!/usr/bin/env python

import re
pattern = re.compile("^please")

question = raw_input("Ask me a question politely: ")
matches = pattern.search(question)

if matches:
    print 'Thank you for being polite.'
else:
    print 'That was not very polite'

