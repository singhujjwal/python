#!/usr/bin/env python
import sys
import re
import fileinput

usage = "usage: %s pattern substitution [files...]" % sys.argv[0]

if len(sys.argv) < 3:
	print usage
	sys.exit(1)

pattern = sys.argv.pop(0)
replacement = sys.argv.pop(0)

regexObj = re.compile(pattern)

for line in fileinput.input():
	regexObj.sub(replacement, line)
	print line

	
