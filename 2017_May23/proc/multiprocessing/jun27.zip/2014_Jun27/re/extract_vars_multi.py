#!/usr/bin/env python
import sys
import re
import pdb

regex = "([A-Za-z_]\w*)\s*=\s*(\d+)"
pattern = re.compile(regex)

while True:
    data = raw_input("Enter string: ")
    for match in pattern.finditer(data):
        print "Name: %s, Value: %s" % match.groups()

