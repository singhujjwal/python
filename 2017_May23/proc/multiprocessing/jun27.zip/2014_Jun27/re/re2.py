#!/usr/bin/env python
import sys
import re

regex = raw_input("Enter regular expression pattern: ")
pattern = re.compile(regex)

try:
    while True:
        data = raw_input("Enter string: ")
        match = pattern.search(data)
        if match:
            print "Group 1: ", match.group(1)
            print "Group 2: ", match.group(2)
            print "All: ", match.groups()

        else:
            print "Match NOT found"
except:
    print "Bye"

