import re

pattern = raw_input("Enter pattern: ")

while True:
    data = raw_input("Enter string: ")
    
#    for m in re.finditer(pattern, data):
#        print m.group()

    print re.findall(pattern, data)

