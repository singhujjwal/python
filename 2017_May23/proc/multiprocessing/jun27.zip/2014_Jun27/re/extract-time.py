#!/usr/bin/env python
import sys
import re

if len(sys.argv) < 2:
    sys.stderr.write("usage: %s file.\n" % sys.argv[0])
    exit(1)

filename = sys.argv[1]

pattern = re.compile("([01]\d|2[0-3]):([0-5]\d):([0-5]\d)")

with open(filename) as file:
    contents = file.read()

matches = pattern.findall(contents)
for match in matches:
    print "%s:%s:%s" % match



