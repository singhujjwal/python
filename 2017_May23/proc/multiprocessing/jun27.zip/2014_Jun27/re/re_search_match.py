import re

pattern = raw_input("Enter pattern: ")

while True:
    data = raw_input("Enter string: ")
    m =  re.search(pattern, data)
    if m:
        print "Pattern found"
        print m.start(), m.end()
    else:
        print "Pattern NOT found"

