#!/usr/bin/env python
import sys
import re
import pdb

if len(sys.argv) < 2:
    print >>sys.stderr, "usage: %s filename." % sys.argv[0]
    exit(1)

regex = "([\w.-]+@[\w.-]+)"
pattern = re.compile(regex)

with open(sys.argv[1]) as src:
    contents = src.read()

for m in pattern.finditer(contents):
    print m.group(0)

