#!/usr/bin/env python
import re
import sys
import urllib

pattern = re.compile("<\s*a\s+href\s*=\s*['\"](.*?)['\"]\s*.*?>")

if len(sys.argv) < 2:
	print "usage: python extract-url.py filename"
	sys.exit(1)
	
response = urllib.urlopen(sys.argv[1])
contents = response.read()

for match in pattern.finditer(contents):
	url = match.groups()[0]
	print url	
