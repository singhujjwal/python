import re

with open("test.txt", "r") as src:
    with open("test1.txt", "w") as dst:
        #data = re.sub(r"\d\d:\d\d:\d\d", "[unknown]", src.read())
        #dst.write(data)

        for line in src:
            dst.write(re.sub(r"\d\d:\d\d:\d\d", "unknown", line))

