import re

pattern = raw_input("Enter pattern: ")

while True:
    data = raw_input("Enter string: ")
    m = re.search(pattern, data)
    if m:
        print "Pattern found"
        print "Group 1: ", m.group(1)
        print "Group 2: ", m.group(2)
        print "Group 0: ", m.group(0)

    else:
        print "Pattern NOT found"

