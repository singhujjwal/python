import sys
import re

if len(sys.argv) < 2:
    print >>sys.stderr, "usage: %s filename.\n" % sys.argv[0]
    exit(1)


def extract_links(filename):
    contents = open(filename).read()

    pattern = r"""
        (href|src)       # match href or src
        \s*              # followed by 0 or more spaces
        =                # followed by = 
        \s*              # followed by 0 or more spaces
        (?P<quote>['"])           # either ' or "
        (.*?)            # contents (the link)
        (?(quote)(?P=quote)|)               # ending with either ' or "
    """

    for match in re.finditer(pattern, contents, re.VERBOSE | re.IGNORECASE):
        yield match.group(3)

for link in extract_links(sys.argv[1]): print link



