#!/usr/bin/env python
import re

pattern = re.compile("([01]\d|2[0-3]):([0-5]\d):([0-5]\d)")

while True:
    input = raw_input("Enter time: ")
    match = pattern.search(input)
    if match:
        print "Hour: %s, Minute: %s, Seconds: %s" % match.groups()
    else:
        print "Invalid time format!"
