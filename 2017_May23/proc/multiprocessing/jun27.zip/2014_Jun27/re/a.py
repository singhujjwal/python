import sys
print sys.modules.keys()

