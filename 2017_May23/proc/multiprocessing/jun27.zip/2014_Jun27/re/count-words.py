#!/usr/bin/env python
import sys
import re

lines = "".join(sys.stdin.readlines())

pattern = re.compile("\w+")
print len(pattern.findall(lines))



