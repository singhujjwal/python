#!/usr/bin/env python
import sys
import re

page = open("sample.html")
data = page.read()
page.close()

pattern = re.compile("<tr>\s*<td>(.*?)</td>\s*<td>(\d+?)</td>\s*<td>(\d+?)</td>")

match_list = pattern.findall(data)
print match_list

total_cost = total_quantity = 0

for (item,quantity,cost) in match_list:
    total_cost += int(cost)
    total_quantity += int(quantity)

print total_cost, total_quantity

    

    

