#!/usr/bin/env python

import re
pattern = re.compile("ca?b")

input_str = raw_input("Enter a string: ")
matches = pattern.search(input_str)

if matches:
    print 'Pattern found...'
else:
    print 'Pattern not found!'
    

