import urllib
import sys

if len(sys.argv) != 2:
    print >>sys.stderr, "usage: %s URL." % sys.argv[0]
    exit(1)

url = sys.argv[1]

response = urllib.urlopen(url)
#print "Got response code: ", response.code
print response.headers.dict

if response.code == 200:
    print response.read()


