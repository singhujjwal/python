#!/usr/bin/env python
import re

pattern = re.compile("\s+\d+\s+")

while True:
    input = raw_input("Enter data: ")
    matches = pattern.finditer(input)
    if matches:
	    print "Matches found: "
	    for match in matches:
		     print "--> ", match.group()
    else:
        print "NO Match found!"
