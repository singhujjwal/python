#!/usr/bin/env python
import re

pattern = re.compile("^(What|How|Why|Who|Where|When|Whom|Which|Did) (is|are|this|was|were|did).*\?$")

while True:
    input = raw_input("Ask me a question: ")
    match = pattern.search(input)
    if match:
        m = input[match.start():match.end()]
        print "Match found: ", m
        print "Groups: ", match.groups()
    else:
        print "NO Match found!"
