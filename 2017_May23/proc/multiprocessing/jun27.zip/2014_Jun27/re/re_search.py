import re

pattern = raw_input("Enter pattern: ")

while True:
    data = raw_input("Enter string: ")
    if re.search(pattern, data):
        print "Pattern found"
    else:
        print "Pattern NOT found"

