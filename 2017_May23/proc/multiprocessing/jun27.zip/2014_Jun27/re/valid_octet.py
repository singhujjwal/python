import re

pattern = "^([1-9]|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])$"

while True:
    t = raw_input("Enter octet: ")
    if re.match(pattern, t): break
    print "Invalid octet - ", t 

print "Octet validated..."


