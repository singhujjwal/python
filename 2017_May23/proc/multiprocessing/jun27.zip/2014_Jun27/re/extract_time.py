#!/usr/bin/env python
import sys
import re


pattern = """
    (?P<hour>      # match hour component  
      [01]\d |     # match 00 to 19 or
      2[0-3]       # match 20 to 23
    )
    :
    (?P<minutes>  # match minutes component
      [0-5]\d     # match :00 to :59
    )             
    :
    (?P<seconds>  # match seconds component
      [0-5]\d     # match :00 to :59
    )             
"""

while True:
    data = raw_input("Enter time (hh:mm:ss): ")
    match = re.search(pattern, data, re.VERBOSE)
    if match:
        print "Extracted valid time: ", match.group()
        #print "Hour: %s, Minutes: %s, Seconds: %s" % (match.group(1), match.group(2), match.group(3))
        #print "Hour: %s, Minutes: %s, Seconds: %s" % (match.group('hour'), match.group('minutes'), 
        #                                        match.group('seconds'))
        rec = match.groupdict()
        print rec
        print "Hour: {hour}, minutes: {minutes}, seconds: {seconds}".format(rec)
        #print match.groupdict()
    else:
        print "Could extract valid time"

