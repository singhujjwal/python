#!/usr/bin/env python
import re

pattern = re.compile("^[A-Za-z0-9]+([\._][A-Za-z0-9]+)*@[A-Za-z0-9]+([\._-][A-Za-z0-9]+)+$")

while True:
    input = raw_input("Enter e-mail id: ")
    match = pattern.search(input)
    if match:
        print "Valid email"
    else:
        print "Invalid email"
