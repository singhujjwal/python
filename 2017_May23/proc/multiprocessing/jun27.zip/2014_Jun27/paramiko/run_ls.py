import paramiko

#key = paramiko.RSAKey(data=base64.decodestring('AAA...'))
#client.get_host_keys().add('ssh.example.com', 'ssh-rsa', key)

client = paramiko.SSHClient()
client.load_system_host_keys()
client.set_missing_host_key_policy(paramiko.WarningPolicy)

client.connect('192.168.43.139', username='joe', password='w3lc0me')
stdin, stdout, stderr = client.exec_command('ls /etc')
for line in stdout:
    print '... ' + line.strip('\n')
client.close()
