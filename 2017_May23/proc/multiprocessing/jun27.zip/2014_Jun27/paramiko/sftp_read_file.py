#!/usr/bin/env python

import paramiko

t = paramiko.Transport(("192.168.43.139", 22))
t.connect(username="joe", password="w3lc0me")
sftp = paramiko.SFTPClient.from_transport(t)

print sftp.open("a_new_file.txt", "r").read()

t.close()
