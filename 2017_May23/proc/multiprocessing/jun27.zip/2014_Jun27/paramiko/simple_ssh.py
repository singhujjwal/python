import base64
import getpass
import os
import socket
import sys
import traceback

import paramiko


# setup logging
paramiko.util.log_to_file('demo_simple.log')

# get hostname
#username = 'testuser'
#hostname = 'localhost'

#username = 'chandra'
#hostname = '192.168.169.5'

username = 'joe'
hostname = '192.168.43.139'


port = 22
password = 'w3lc0me'


# now, connect and use paramiko Client to negotiate SSH2 across the connection
try:
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.WarningPolicy)

    print '*** Connecting...'
    client.connect(hostname, port, username, password)
    chan = client.invoke_shell()

    #print "Connected..."
    #chan.setblocking(False)

    output = chan.exec_command("uname -a")
    print output

#    chan.send("ls /etc\r")
#    print "Sent command - uname -a"

    while chan.recv_ready():
        print chan.recv(1), 

    print "Finished."
    chan.close()

    client.close()

except Exception, e:
    print '*** Caught exception: %s: %s' % (e.__class__, e)
    traceback.print_exc()
    try:
        client.close()
    except:
        pass
    sys.exit(1)
