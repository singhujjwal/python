#!/usr/bin/env python

import paramiko

t = paramiko.Transport(("192.168.43.139", 22))
t.connect(username="joe", password="w3lc0me")

sftp = paramiko.SFTPClient.from_transport(t)

#dirlist = sftp.listdir('.')
#print "Dirlist:", dirlist

sftp.put("sftp_upload_file.py", "sftp_upload_file.py")

# sftp.get("remotefile", "localfile")
# sftp.mkdir("remote-dir")
# sftp.open("remote-file", "w").write("this is a new file\n")
# print sftp.open("remote-file", "r").read()

sftp.open("a_new_file.txt", "w").write("This is a test file\n")

t.close()
