#!/usr/bin/env python
from poplib import POP3
import sys

if len(sys.argv) < 4:
    print "usage: %s host username password" % sys.argv[0]
    sys.exit(-1)
    

mail = POP3(sys.argv[1])
mail.user(sys.argv[2])
mail.pass_(sys.argv[3])

(code, mail_list, size) = mail.list()
for entry in mail_list:
    n, size = entry.split()
    (code, data, size) = mail.retr(int(n))
    print "-" * 40
    for line in data:
        if "From" in line: print line
        if "Subject" in line: print line
    print "=" * 40

    
