#!/usr/bin/env python
from smtplib import SMTP

from_addr = "testuser@chandrashekar.info" 
to_list = ["testuser@chandrashekar.info", "chandrashekar.babu@gmail.com"]

data = """
From: Chandrashekar <email@chandrashekar.info>
Subject: This is a new message 
Cc: Chandrashekar Babu <chandrashekar.babu@gmail.com>

This is a dummy message 
slkfsklfjsdklfsd
flskjf ksdljflsdf
dsflksd jfklsdjfsd
fdskl fjsdklfjsdf
"""

mail = SMTP("mail.chandrashekar.info")
mail.set_debuglevel(7)
mail.ehlo_or_helo_if_needed()
mail.login("testuser", "w3lc0me")

mail.sendmail(from_addr, to_list, data)


