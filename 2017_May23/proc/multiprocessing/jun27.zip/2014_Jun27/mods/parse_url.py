from urllib import urlencode
from urlparse import parse_qs

form_data = dict(
    name="john doe",
    email="john@gmail.com",
    password="john^@&aaa")

r = urlencode(form_data)

print "r = ", r

print "form data = ", parse_qs(r)

