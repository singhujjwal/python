#!/usr/bin/env python
import htmllib

class MyParser(htmllib.HTMLParser):
    def handle_starttag(self, tag, method, attr):
        print tag, method, attr


f = open("../ask.html")
contents = f.read()
f.close()

a = MyParser(contents)
