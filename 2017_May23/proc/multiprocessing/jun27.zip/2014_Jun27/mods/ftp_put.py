from ftplib import FTP

site = FTP("ftp.chandrashekar.info")
site.login("testuser", "w3lc0me")
site.cwd("/www")

with open("README", "r") as f:
    site.storbinary("STOR README", f)


