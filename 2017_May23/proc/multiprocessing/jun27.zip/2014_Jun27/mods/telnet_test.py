from telnetlib import Telnet

t = Telnet("localhost")
t.read_until("login: ")
t.write("training\n")

t.read_until("Password: ")
t.write("welcome\n")

t.read_until("$ ")
t.write("whoami\n")
t.read_all()


