from subprocess import Popen

hosts = "localhost", "192.168.43.230", "127.0.0.1"

children = { }

for h in hosts:
    children[h] = Popen("ls " + h, stdout=PIPE)


for h in hosts:
    for line in children[h].stdout: 
        print h, ": ", line
    print "-" * 40

