#!/usr/bin/env python
import urllib
import urllib2

# gws_rd=ssl&sesinv=1#q=Python

url = "http://www.google.co.in/search?"
form_data = {}
form_data['q'] = raw_input("Enter search query: ")
form_data['hl'] = "en"
form_data['ie'] = "ISO-8859-1"
form_data['btnG'] = "Google Search"
data = urllib.urlencode(form_data)
headers = {'User-Agent': "Mozilla/5.0 (compatible; MSIE 5.5; Windows NT)"}
url += data

try:
    request = urllib2.Request(url,"", headers)
    response = urllib2.urlopen(request)
    print response.read()
except urllib2.HTTPError, e:
    print "HTTPError generated:", e
except urllib2.URLError, e:
    print "URLError generated"




