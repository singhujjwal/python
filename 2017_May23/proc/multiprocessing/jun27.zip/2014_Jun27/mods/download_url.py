import sys
from urllib import urlopen

response = urlopen("http://www.chandrashekar.info/files/python/find_iter_exercise.py")

with open("find_iter_exercise.py", "w") as out:
    out.write(response.read())


