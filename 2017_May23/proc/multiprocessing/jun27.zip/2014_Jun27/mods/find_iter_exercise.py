"""
Complete this program by implementing the finditer() function.
[http://www.chandrashekar.info/files/python/find_iter_exercise.py]
==================================================================
finditer() function should be implemented as a generator that 
yields indices of a substring in a main string.
"""

def finditer(main_string, sub_string):
    """
    Implement a generator that yields each index of sub_string 
    in the main_string
    """
    pass # To be implemented

if __name__ == '__main__':
    
    s = "this is a test string test test is a test with test words"

    for i in finditer(s, "test"):
        print i,   #OUTPUT: 10 22 27 37 47

    


