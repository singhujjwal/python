import sys
from urllib import urlopen

response = urlopen("http://www.chandrashekar.info/about.html")

print response.read(),


