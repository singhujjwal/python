#!/usr/bin/env python
import sys
import re
import socket
import time

if len(sys.argv) < 2:
	print "usage: %s URL" % sys.argv[0]
	sys.exit(-1)

pattern = re.compile("^http://(.+?)(/.*)")
match = pattern.search(sys.argv[1])
hostname = match.group(1)
path = match.group(2)

print "Connecting to %s, accessing %s" % (hostname, path)

start_time = time.time()
connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connection.connect((hostname, 80))
connection.send("GET " + path)
data = connection.recv(10)
connection.close()
end_time = time.time()
duration = end_time - start_time
print "Request took %f seconds" % duration

output = open("webget.html", "w")
output.write(data)
output.close()









