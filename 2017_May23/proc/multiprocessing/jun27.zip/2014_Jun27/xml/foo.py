def bar(v):
    #v[0] = 100
    #v[1] = 200
    v = [ x*x for x in v ]
    print "In bar v = ", v

def foo():
    a = [10, 20, 30]
    print "In foo: a = ", a
    bar(a)
    print "In foo: a = ", a

foo()

