import pdb

def baz():
    c = 300
    print "c = ", c

def bar():
    b = 200
    baz()


def foo():
    a = 100
    bar()

pdb.set_trace()
foo()


