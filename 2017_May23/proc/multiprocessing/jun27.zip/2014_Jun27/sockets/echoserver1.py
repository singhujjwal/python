#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM, SOMAXCONN

mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.bind(("127.0.0.1", 5000))

print "Echo server listening on port 5000\n"
mySocket.listen(SOMAXCONN)

try:
    while True:
        (client, addr) = mySocket.accept()
        print "Got incoming connection from: " + `addr`
        while True:
            data = client.recv(50)
            print "Client sent: " + data
            data = data.strip()
            client.send(data.upper() + "\n")
            if data.endswith("bye"):
                print "Closing client connection"
                break
        client.send("Bye bye\n")
        client.close()
except:
    mySocket.close()
    client.close()

