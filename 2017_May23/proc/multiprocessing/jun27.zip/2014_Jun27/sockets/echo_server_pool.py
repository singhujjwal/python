#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM, SOMAXCONN
from threading import Thread
from Queue import Queue
import sys

def handle_connection(conn_queue):
    while True:
        sock = conn_queue.get()
        while True:

            data = sock.recv(50)
            if not data:
                print "Client sent no data."
                break
            data = data.strip()
            print "Client sent: " + data
            sock.send(data.upper() + "\n")
            if data.endswith("bye"):
                print "Closing client connection"
                break
        sock.send("Bye bye\n")
        sock.close()


if len(sys.argv) < 3:
    print "usage: %s hostname port"
    exit(1)

host = sys.argv[1]
port = int(sys.argv[2])
MAX_CONNECTIONS = 100

server = socket(AF_INET, SOCK_STREAM)
server.bind((host, port))

print "Echo server listening on port 5000"
server.listen(SOMAXCONN)

conn_queue = Queue(100)
thread_pool = []
for i in range(MAX_CONNECTIONS):
    th = Thread(target=handle_connection, args=[conn_queue])
    thread_pool.append(th)
    th.start()

try:
    while True:
        (client, addr) = server.accept()
        print "Got incoming connection from: " + `addr`
        conn_queue.put(client)
except:
    server.close()

