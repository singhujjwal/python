#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM

mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.connect(("127.0.0.1", 6050))

while True:
	input = raw_input("Enter a string: ")
	mySocket.send(input)
	data = mySocket.recv(50)
	print "Server sent: " + data
	if data.endswith("BYE"):
		break

mySocket.close()





