from multiprocessing.connection import Listener
from time import ctime

address = ('localhost', 6000) 
listener = Listener(address)

while True:
    conn = listener.accept()
    print 'connection accepted from', listener.last_accepted
    conn.send_bytes(ctime())
    conn.close()

listener.close()
