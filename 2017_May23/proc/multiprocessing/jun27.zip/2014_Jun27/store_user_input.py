from sys import stdin

print "Enter some string: "
with open("user_input.txt", "w") as out:
    out.write(stdin.read())

