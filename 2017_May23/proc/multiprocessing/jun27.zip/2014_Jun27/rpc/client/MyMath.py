from multiprocessing.managers import BaseManager

class MathsClass(object):
    def add(self, x, y):
        print "add method called."
        return x + y

    def mul(self, x, y):
        print "mul method called."
        return x * y

class MyManager(BaseManager): pass

