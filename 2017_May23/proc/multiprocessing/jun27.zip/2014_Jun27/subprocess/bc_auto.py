from time import time, sleep
from subprocess import Popen, PIPE

p = Popen(["bc", "-l"], stdout=PIPE, stdin=PIPE)
p.stdin.write("scale=2000\n")
p.stdin.write("4*a(1)\n")
p.stdin.close()

with open("pi.out", "w") as outfile:
    for line in p.stdout:
        outfile.write(line)

print "Complete"

