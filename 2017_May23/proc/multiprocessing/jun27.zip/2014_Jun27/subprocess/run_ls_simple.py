from subprocess import Popen

#p = Popen(["ls", "-l"]) # ls -l

#p = Popen("ls -l", shell=True) # sh -c "ls -l"

p = Popen("ls | grep ^r", shell=True)
p.wait()

