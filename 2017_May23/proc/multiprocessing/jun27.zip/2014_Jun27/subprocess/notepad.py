from subprocess import Popen, PIPE
from time import sleep

p = Popen(["atom"])

for i in range(5):
    print "Counting", i
    sleep(1)

print "Terminating notepad..."
p.kill()


