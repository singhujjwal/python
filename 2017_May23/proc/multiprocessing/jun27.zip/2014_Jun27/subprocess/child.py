#!/usr/bin/python

import os

print "New program process id = ", os.getpid()
