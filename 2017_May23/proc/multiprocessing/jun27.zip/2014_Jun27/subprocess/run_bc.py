from subprocess import Popen, PIPE
from time import time

commands = """
scale=3000
4*a(1)
quit
"""

p = Popen(["bc", "-l"], stdin=PIPE, stdout=PIPE)

start = time()
p.stdin.write(commands)
p.stdin.close()
p.wait()
end = time()

print "Duration: ", end - start, "seconds"

