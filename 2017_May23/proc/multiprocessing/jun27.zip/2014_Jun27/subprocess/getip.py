from subprocess import Popen, PIPE

child = Popen("/sbin/ifconfig", stdout=PIPE, stderr=PIPE)

for line in child.stdout:
    #if "inet addr" in line: 
    #    print line.strip().split(" ")[1].split(":")[1]
    
    if "inet " in line:
        print line.strip().split(" ")[1]

child.wait()

