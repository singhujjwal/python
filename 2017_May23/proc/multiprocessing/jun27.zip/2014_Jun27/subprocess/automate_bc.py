from subprocess import PIPE, Popen
from time import time
from sys import stdout

cmd = Popen(["bc", "-l"], stdout=PIPE, stdin=PIPE)
cmd.stdin.write("scale=2000\n")

start = time()
cmd.stdin.write("4*a(1)\n")
#cmd.stdin.write("quit\n")
#cmd.stdin.flush()
cmd.stdin.close()
cmd.wait()
end = time()

#for line in cmd.stdout:
#    print line,
#    stdout.flush()

#cmd.wait()
#end = time()

print "Duration: %f seconds" % (end - start)
