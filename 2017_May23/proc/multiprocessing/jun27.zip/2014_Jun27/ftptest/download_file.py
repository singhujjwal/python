from ftplib import FTP
from sys import stdout

site = FTP("ftp.chandrashekar.info", "testuser", "w3lc0me")

site.cwd("/www/files/python")



try:
    with open("jun25.zip", "wb") as f:
        
        def store_local(data):
            stdout.write("#")
            stdout.flush()
            f.write(data)

        site.retrbinary("RETR jun25.zip", store_local)

except Exception as e:
    print "Caught an error: ", e
    from os import unlink
    unlink("jun25.zip")

site.quit()

