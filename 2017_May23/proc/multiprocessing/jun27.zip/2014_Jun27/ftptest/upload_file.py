from ftplib import FTP

site = FTP("ftp.chandrashekar.info", "testuser", "w3lc0me")

site.cwd("/www/files/python")

with open("a123.dat") as f:
    site.storbinary("STOR a123.dat", f)

site.quit()

