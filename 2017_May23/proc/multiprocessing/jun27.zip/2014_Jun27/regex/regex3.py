import re

pattern = re.compile(r'(\d+)')


while True:
    subject = raw_input("Enter a string: ")
    #for match in pattern.finditer(subject):
    #    print match.group(0)
    print pattern.findall(subject)



