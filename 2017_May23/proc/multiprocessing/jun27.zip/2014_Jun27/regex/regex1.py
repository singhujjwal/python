import re
pattern = r'(\d+)'


while True:
    subject = raw_input("Enter a string: ")
    match = re.search(pattern, subject)
    if not match: 
        print "Match not found"
    else:
        print match.group(0)


