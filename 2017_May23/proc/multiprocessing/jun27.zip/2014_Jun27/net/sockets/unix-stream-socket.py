#!/usr/bin/env python
from socket import socket, AF_UNIX, SOCK_STREAM

mySocket = socket( AF_UNIX, SOCK_STREAM )
mySocket.bind("a.sock")

mySocket.listen(5)

print "Test UNIX server listening for connections\n"

while True:
    client, addr = mySocket.accept()

    data = client.recv(64)
    print "Received data: " + `data` + " from " + `addr`

