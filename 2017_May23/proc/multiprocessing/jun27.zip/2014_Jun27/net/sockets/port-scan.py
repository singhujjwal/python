#!/usr/bin/env python
import socket
import sys

MAX_PORT = 1024
port_list = []

if len(sys.argv) < 2:
	print "usage: %s hostname" % sys.argv[0]
	sys.exit(-1)



for port in range(1, MAX_PORT):
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.connect((sys.argv[1], port))
		s.close()
		port_list.append(port)
		print "Success: ", port
	except socket.error, message:
		print "Failed: ", port

print port_list







