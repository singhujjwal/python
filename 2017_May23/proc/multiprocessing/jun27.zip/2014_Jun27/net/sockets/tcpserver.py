#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM

mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.bind(("127.0.0.1", 5050))

print "Echo server listening on port 5050\n"
mySocket.listen(5)

while True:
	try:
		(client, addr) = mySocket.accept()
		print "Got incoming connection from: " + `addr`
		client.send("Hi, Thanks for connecting...\n")
		client.send("Bye\n")
		client.close()
	except KeyboardInterrupt:
		mySocket.close()



