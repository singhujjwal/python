#!/usr/bin/env python
from socket import socket, AF_INET, AF_UNIX, SOCK_DGRAM

mySocket = socket( AF_INET, SOCK_DGRAM )
mySocket.bind( ("127.0.0.1", 5000) )
print "Test server listening on port 5000\n"

while True:
    (message, (host, port)) = mySocket.recvfrom( 50 ) 
    print "Received message: %s from %s at %d" % (message, host, port)


