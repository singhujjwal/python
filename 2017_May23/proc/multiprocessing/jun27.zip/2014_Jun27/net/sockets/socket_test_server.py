#!/usr/bin/env python

from socket import socket, gethostbyname, AF_INET, SOCK_DGRAM

PORT_NUMBER = 5000

hostName = gethostbyname( 'localhost' )

mySocket = socket( AF_INET, SOCK_DGRAM )
mySocket.bind( (hostName, PORT_NUMBER) )

print "Test server listening on port %d\n" % PORT_NUMBER

print "If you haven't started one or more client scripts already, do it now.\n"

while 1:
    (data, addr) = mySocket.recvfrom( 50 ) 
    print "Received packet from: " + `addr` + ", " + data

