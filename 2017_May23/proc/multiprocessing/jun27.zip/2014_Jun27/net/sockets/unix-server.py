#!/usr/bin/env python
from socket import socket, AF_INET, AF_UNIX, SOCK_DGRAM

mySocket = socket( AF_UNIX, SOCK_DGRAM )
mySocket.bind("a.sock")

print "Test server listening on port 5000\n"

while True:
    data = mySocket.recvfrom( 50 ) 
    print "Received packet: " + data

