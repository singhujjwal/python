#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
from threading import Thread

import re

def handle_connection(client):
    data = client.recv(1024)
    print "Header is -> ", data
    pattern = re.compile("^Filename: (\S+), Filesize: (\d+).*")
    matches = pattern.search(data)

    filename = matches.group(1)
    filesize = int(matches.group(2))
    contents = client.recv(filesize)

    outputfile = open("incoming/" + client.getpeername()[0] + "-" + filename, "w")
    outputfile.write(contents)
    outputfile.close()
    client.close()

        
server = socket(AF_INET, SOCK_STREAM)
server.bind(("127.0.0.1", 5050))

print "Echo server listening on port 5050\n"
server.listen(5)

while True:
    (client, addr) = server.accept()
    print "Got incoming connection from: " + `addr`
    #thread.start_new_thread(handle_connection, (client,))
    th = Thread(target=handle_connection, args=[client])
    th.start()







