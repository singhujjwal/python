#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
from os.path import basename

server = socket(AF_INET, SOCK_STREAM)
server.connect(("127.0.0.1", 5050))

filename = raw_input("Enter filename: ")
with open(filename, "r") as f:
    contents = f.read()


header = "Filename: %s, Filesize: %d\n" % (basename(filename), len(contents))
header += " " * (1024 - len(header))

contents = header + contents

server.send(contents)
server.close()








