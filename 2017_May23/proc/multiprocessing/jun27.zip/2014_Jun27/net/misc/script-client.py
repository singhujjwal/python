#!/usr/bin/env python
from socket import *
import sys
import marshal

class Foo:
   def __init__(self):
       print "I'm a constructor..."

foo = Foo()

str = "a = 10; b = 20; a,b = b,a; print a, b"

server = socket(AF_INET, SOCK_STREAM)
server.connect((sys.argv[1], int(sys.argv[2])))

f = file(sys.argv[3])
server.send(marshal.dumps(str))
f.close()
server.close()


