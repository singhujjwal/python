from ftplib import FTP

site = FTP("ftp.chandrashekar.info")
site.login("testuser", "w3lc0me")
site.cwd("/www/files")

with open("python.vimrc", "w") as f:
    site.retrbinary("RETR python.vimrc", f.write)


