#!/usr/bin/env python
import urllib
import urllib2

url = "http://www.ask.com/web?"
form_data = {}
form_data['q'] = raw_input("Enter search query: ")
form_data['qsrc'] = "0"
form_data['o'] = "0"
form_data['l'] = "dir"

data = urllib.urlencode(form_data)
headers = {'User-Agent': "Mozilla/5.0 (compatible; MSIE 5.5; Windows NT)"}
url += data

try:
    request = urllib2.Request(url,"", headers)
    response = urllib2.urlopen(request)
    print response.read()
except urllib2.HTTPError, e:
    print "HTTPError generated"
except urllib2.URLError, e:
    print "URLError generated"




