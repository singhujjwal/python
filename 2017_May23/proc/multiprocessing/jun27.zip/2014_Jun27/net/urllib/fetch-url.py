#!/usr/bin/env python
import urllib2
import sys

if len(sys.argv) < 2:
    print "usage: %s URL" % sys.argv[0]

request = urllib2.urlopen(sys.argv[1])
print request.read()

