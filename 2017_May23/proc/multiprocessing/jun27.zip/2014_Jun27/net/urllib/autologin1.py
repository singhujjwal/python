#!/usr/bin/env python
import urllib
import urllib2


url = "http://localhost/cgi-bin/auth.cgi"

form_data = {}

form_data['uname'] = "joe"
form_data['passwd'] = "welcome"

data = urllib.urlencode(form_data)

url = url + "?" + data
print "URL Sent: ", url

request = urllib2.Request(url)
response = urllib2.urlopen(request)
print response.read()

