#!/usr/bin/env python
import sys
import urllib
import urllib2
import re

def fetch_url_list(url_string):
    web_request  = urllib2.urlopen(url_string)
    web_page     = web_request.read()
    href_pattern = re.compile("<\s*a\s+href\s*=\s*['\"](.*?)['\"](\s*>|\s)")
    url_tuple     = href_pattern.findall(web_page)
    print url_tuple
    raw_input("Enter to continue")
    url_list = []
    for (i, j) in url_tuple:
        url_list.append(urllib.basejoin(url_string, i))
        
    return url_list
    

if len(sys.argv) < 2:
    print "usage: %s URL" % sys.argv[0]
    sys.exit(-1)

urls = fetch_url_list(sys.argv[1])
for url in urls:
    print url
    
