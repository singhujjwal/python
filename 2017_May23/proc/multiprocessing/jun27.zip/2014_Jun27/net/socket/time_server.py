from socket import socket, AF_INET, SOCK_STREAM
from time import ctime

listener = socket(AF_INET, SOCK_STREAM)

listener.bind(("localhost", 8080))
listener.listen(10000)

while True:
    print "Waiting for connection: "
    client, addr = listener.accept()
    print "Got connection from client: ", addr
    client.send(ctime())
    client.close()

