#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
from pool import WorkerPool

def process_client(client):
    while True:
        data = client.recv(50)
        print "Client sent: " + data
        if not data: break
        client.send(data.upper())
        if "bye" in data: break

    client.close()


server = socket(AF_INET, SOCK_STREAM)
server.bind(("127.0.0.1", 5050))
print "Echo server listening on port 5050\n"
server.listen(5)
pool = WorkerPool(capacity=5, target=process_client)

try:
    while True:
        (client, addr) = server.accept()
        print "Got incoming connection from: " + `addr`
        pool.submit(client)
except:
    server.close()
    client.close()

