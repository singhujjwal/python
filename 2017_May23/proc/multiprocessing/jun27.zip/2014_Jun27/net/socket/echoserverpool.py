#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
from threading import Thread
from Queue import Queue

def process_client(client):
    while True:
        data = client.recv(50)
        print "Client sent: " + data
        if not data: break
        data = data.strip()
        client.send(data.upper())
        if "bye" in data: break

    client.close()

def worker(queue):
    while True:
        client = queue.get()
        process_client(client)


mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.bind(("127.0.0.1", 5050))
print "Echo server listening on port 5050\n"
mySocket.listen(5)

num_workers = 5

queue = Queue(num_workers)
threads = {}

for i in range(num_workers):
    threads[i] = Thread(target=worker, args=(queue,))
    threads[i].start()

try:
    while True:
        (client, addr) = mySocket.accept()
        print "Got incoming connection from: " + `addr`
        queue.put(client)
        #process_client(client)
        #Thread(target=process_client, args=(client,)).start()

except:
    mySocket.close()
    client.close()





