from Queue import Queue
from threading import Thread
class WorkerPool:

    def __init__(self, capacity, target, args=()):
        self.capacity = capacity
        self.target = target
        self.args = args
        self.queue = Queue(capacity)
        self.workers = { }

        for i in range(capacity):
            self.workers[i] = Thread(target=self.handle_work)
            self.workers[i].start()

    def submit(self, work):
        self.queue.put(work)

    def handle_work(self):
        while True:
            work = self.queue.get()
            self.target(work, *self.args)

