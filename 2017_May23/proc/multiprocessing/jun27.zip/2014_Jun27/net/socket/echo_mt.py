from socket import socket, AF_INET, SOCK_STREAM
from time import ctime
from threading import Thread

def handle_connection(c):
    while True:
        line = c.recv(100)
        if not line: break
        c.send(line.upper())
    c.close()

listener = socket(AF_INET, SOCK_STREAM)
listener.bind(("localhost", 7000))
listener.listen(10000)

while True:
    print "Waiting for connection: "
    client, addr = listener.accept()
    print "Got connection from client: ", addr
    worker = Thread(target=handle_connection, args=(client,))
    worker.start()

