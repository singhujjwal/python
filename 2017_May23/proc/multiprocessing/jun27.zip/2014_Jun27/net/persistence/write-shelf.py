import shelve
store = shelve.open("data.dat")
name = "James"
info = {'city' : 'Chennai', 'temperature' : 38, 'country' : 'India' }
scores = [555, 66, 23, 432, 77, 22]
store['n'] = name
store['info'] = info
store['marks'] = scores
store.close()


