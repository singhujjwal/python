import pickle
info = pickle.load(open("info.dat"))
print info

