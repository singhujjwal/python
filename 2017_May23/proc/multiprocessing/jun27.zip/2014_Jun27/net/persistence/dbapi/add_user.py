import sqlite3
from md5 import md5
from getpass import getpass

conn = sqlite3.connect("accessdb")

insert_sql = """
    INSERT INTO users(name, password) VALUES(?,?)
"""
cursor = conn.cursor()

while True:
    name = raw_input("Enter name: ")
    if not name: break
    password = md5(getpass("Enter password: ")).hexdigest()
    cursor.execute(insert_sql, (name, password))
    print "-" * 30

conn.commit()
conn.close()

