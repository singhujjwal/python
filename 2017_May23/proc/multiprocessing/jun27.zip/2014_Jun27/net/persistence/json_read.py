import json

#json.dump(user_info, open("json.dat", "wb"))

d = json.load(open("data.json", "rb"))
for k, v in d.items(): print k, "=", v




