from PythonOrgClient import *
from ChandrashekarInfo import *
import asyncore

p = PythonOrgClient("www.python.org", "/")
c = ChandrashekarInfo("www.chandrashekar.info", "/")

asyncore.loop()

