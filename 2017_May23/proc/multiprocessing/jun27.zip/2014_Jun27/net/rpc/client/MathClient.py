from MyMath import MyManager
import pdb

manager = MyManager(address=('127.0.0.1', 6060), authkey="secret")

pdb.set_trace()

manager.connect()
math = manager.Maths()
print math.add(10, 20)
print math.mul(20, 30) 





