from ConfigParser import ConfigParser

c = ConfigParser()
c.read("config.ini")

print c.get("main", "host")
print c.get("admin", "max_conn")

c.set("main", "host", "64.55.44.33")
c.add_section("new_section")
c.set("new_section", "port", 5454)

with open("config.ini", "w") as out: c.write(out)

