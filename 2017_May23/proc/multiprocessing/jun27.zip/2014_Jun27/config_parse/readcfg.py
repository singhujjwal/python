from ConfigParser import ConfigParser

conf = ConfigParser()
conf.read("config.ini")

print "main -> host =", conf.get("main", "host")

print "connection -> max_conn =", conf.get("connection", "max_conn")
