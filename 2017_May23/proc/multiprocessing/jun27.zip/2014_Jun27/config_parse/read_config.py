from ConfigParser import ConfigParser

c = ConfigParser()
c.read("config.ini")

print c.get("main", "host")
print c.get("admin", "max_conn")

