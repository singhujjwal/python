import sys
from urllib2 import urlopen, Request
from urllib import urlencode

form_data = {
    "uname" : "john",
    "passwd" : "john123"
}


req_headers = {
    "Host"       : "localhost:7000",
    "User-Agent" : "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:22.0) Gecko/20100101 Firefox/22.0",
    "Accept"     : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
}

#r = Request("http://localhost:7000/login.cgi", urlencode(form_data), req_headers)
r = Request("http://localhost:7000/login.cgi" + "?" + urlencode(form_data), headers=req_headers)


response = urlopen(r)

print response.read(),


