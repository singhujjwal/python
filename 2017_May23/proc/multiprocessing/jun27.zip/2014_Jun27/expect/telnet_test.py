import pexpect
child = pexpect.spawn('telnet -l joe 192.168.43.139', 
                       logfile=open("log.txt", "w"))

#child.expect('login: ')
#child.sendline('joe')

child.expect('Password:')
child.sendline('w3lc0me')

child.expect('joe@slesvm:~> ')
child.sendline('uname -a')
child.expect('joe@slesvm:~> ')
print child.before

child.sendline("ls")
child.expect("joe@slesvm:~> ")
print child.before


child.sendline('exit')
