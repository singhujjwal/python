from getpass import getpass
import logging
import sys
from telnetlib import Telnet
import re
from time import sleep

HOST = "192.168.43.139"
user = "joe" 
password = "w3lc0me" 

tn = Telnet(HOST)

tn.read_until("login: ")
tn.write(user + "\r")

tn.read_until("Password:", timeout=5)
tn.write(password + "\r")

tn.read_until("?", timeout=5)
tn.write("vt100\r")

tn.read_until(r"> ")
tn.write("uname -a\r")

print tn.read_until("> ")

tn.write("exit\r")


