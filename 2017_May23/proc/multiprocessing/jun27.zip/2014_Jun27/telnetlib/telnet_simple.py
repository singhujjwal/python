from telnetlib import Telnet

HOST = "192.168.43.139"
user = "joe" 
password = "w3lc0me" 

tn = Telnet(HOST)
#tn.set_debuglevel(7)

tn.read_until("login: ")
tn.write(user + "\r")

tn.read_until("Password:", timeout=5)
tn.write(password + "\r")

tn.read_until("?", timeout=5)
tn.write("vt100\r")

tn.read_until(r"joe@slesvm:~> ")
tn.write("uname -a\r")

print tn.read_until("joe@slesvm:~> ")

tn.write("exit\r")


